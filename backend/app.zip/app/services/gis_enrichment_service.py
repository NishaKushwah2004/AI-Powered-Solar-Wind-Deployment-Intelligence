import logging

from app.environmental.clients.sentinel_client import SentinelClient
from app.environmental.exceptions import SentinelServiceError
from app.gis.clients.elevation_client import ElevationClient
from app.gis.clients.osm_client import OSMClient
from app.gis.coordinates import validate_coordinates
from app.gis.exceptions import InvalidCoordinatesError
from app.gis.models.gis_result import GISResult

logger = logging.getLogger(__name__)


class GISEnrichmentService:
    """
    Service responsible for enriching a site using
    external GIS and environmental data providers.

    Current providers:
    - OpenStreetMap (roads, substations, transmission
      lines, water bodies, protected areas, land use)
    - Open-Elevation (elevation, land slope)
    - Copernicus Sentinel Hub (vegetation index),
      optional - degrades gracefully when unconfigured.

    Future providers:
    - NASA POWER
    - Open-Meteo
    - ERA5
    """

    def __init__(self):
        self.osm_client = OSMClient()
        self.elevation_client = ElevationClient()
        self.sentinel_client = SentinelClient()

    def enrich_site(
        self,
        latitude: float,
        longitude: float,
    ) -> GISResult:
        """
        Enrich a site using GIS providers.
        """

        if not validate_coordinates(latitude, longitude):
            raise InvalidCoordinatesError(
                "Invalid latitude or longitude."
            )

        land_use = self.osm_client.get_land_use(
            latitude,
            longitude,
        )

        elevation = self.elevation_client.get_elevation(
            latitude,
            longitude,
        )

        road_distance = (
            self.osm_client.get_nearest_road_distance(
                latitude,
                longitude,
            )
        )

        substation_distance = (
            self.osm_client.get_nearest_substation_distance(
                latitude,
                longitude,
            )
        )

        transmission_distance = (
            self.osm_client.get_nearest_transmission_line_distance(
                latitude,
                longitude,
            )
        )

        water_body_distance = (
            self.osm_client.get_nearest_water_body_distance(
                latitude,
                longitude,
            )
        )

        protected_area_distance = (
            self.osm_client.get_nearest_protected_area_distance(
                latitude,
                longitude,
            )
        )

        land_slope = self.elevation_client.get_slope(
            latitude,
            longitude,
        )

        vegetation_index = self._get_vegetation_index(
            latitude,
            longitude,
        )

        infrastructure = []

        if road_distance is not None:
            infrastructure.append("Road")

        if substation_distance is not None:
            infrastructure.append("Substation")

        if transmission_distance is not None:
            infrastructure.append("Transmission Line")

        return GISResult(
            land_use=land_use,
            elevation=elevation,
            existing_infrastructure=", ".join(infrastructure)
            if infrastructure
            else None,
            road_distance=road_distance,
            nearest_substation_distance=substation_distance,
            nearest_transmission_line_distance=transmission_distance,
            water_body_distance=water_body_distance,
            protected_area_distance=protected_area_distance,
            land_slope=land_slope,
            vegetation_index=vegetation_index,
        )

    def _get_vegetation_index(
        self,
        latitude: float,
        longitude: float,
    ) -> float | None:
        """
        Retrieve the vegetation index for a site.

        Sentinel Hub is an optional provider - any failure
        or missing credentials should never break GIS
        enrichment as a whole.
        """

        try:
            return self.sentinel_client.get_vegetation_index(
                latitude,
                longitude,
            )

        except SentinelServiceError:
            logger.warning(
                "Vegetation index unavailable for (%s, %s); "
                "continuing without Sentinel data.",
                latitude,
                longitude,
            )
            return None