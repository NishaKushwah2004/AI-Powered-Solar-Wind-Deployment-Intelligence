from pydantic import BaseModel, ConfigDict


class GISResult(BaseModel):
    """
    Result returned after GIS enrichment.
    """

    model_config = ConfigDict(from_attributes=True)

    land_use: str | None = None

    elevation: float | None = None

    road_distance: float | None = None

    nearest_substation_distance: float | None = None

    nearest_transmission_line_distance: float | None = None

    existing_infrastructure: str | None = None

    # ----------------------------
    # Milestone 2 - Environmental / Geographic Intelligence
    # ----------------------------

    water_body_distance: float | None = None

    protected_area_distance: float | None = None

    land_slope: float | None = None
    """Terrain slope in degrees."""

    vegetation_index: float | None = None
    """NDVI-based vegetation index (Copernicus Sentinel)."""